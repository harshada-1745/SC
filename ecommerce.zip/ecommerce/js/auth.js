function switchTab(tab) {
  document.getElementById('loginForm').classList.toggle('active', tab === 'login');
  document.getElementById('signupForm').classList.toggle('active', tab === 'signup');
  document.getElementById('loginTab').classList.toggle('active', tab === 'login');
  document.getElementById('signupTab').classList.toggle('active', tab === 'signup');
}

function showMsg(id, text, type) {
  const el = document.getElementById(id);
  el.textContent = text; el.className = `msg ${type}`;
  setTimeout(() => el.textContent = '', 3000);
}

function socialLogin(provider) {
  const fakeUser = { name: `${provider} User`, email: `user@${provider.toLowerCase()}.com` };
  localStorage.setItem('luxe_user', JSON.stringify(fakeUser));
  showMsg('loginMsg', `✅ Logged in with ${provider}!`, 'success');
  setTimeout(() => window.location.href = 'index.html', 1000);
}

document.getElementById('signupPassword')?.addEventListener('input', function () {
  const val = this.value; let score = 0;
  if (val.length >= 8) score++;
  if (/[A-Z]/.test(val)) score++;
  if (/[0-9]/.test(val)) score++;
  if (/[^A-Za-z0-9]/.test(val)) score++;
  const fill = document.getElementById('strengthFill');
  const colors = ['#e74c3c', '#f39c12', '#f1c40f', '#2ecc71'];
  fill.style.width = (score * 25) + '%';
  fill.style.background = colors[score - 1] || '#eee';
});

document.getElementById('loginForm')?.addEventListener('submit', function (e) {
  e.preventDefault();
  const email = document.getElementById('loginEmail').value;
  const pass = document.getElementById('loginPassword').value;
  const users = JSON.parse(localStorage.getItem('luxe_users') || '[]');
  const match = users.find(u => u.email === email && u.password === pass);
  if (match) {
    localStorage.setItem('luxe_user', JSON.stringify({ name: match.name, email: match.email }));
    showMsg('loginMsg', '✅ Welcome back! Redirecting…', 'success');
    setTimeout(() => window.location.href = 'index.html', 1200);
  } else {
    showMsg('loginMsg', '❌ Invalid email or password.', 'error');
  }
});

document.getElementById('signupForm')?.addEventListener('submit', function (e) {
  e.preventDefault();
  const name = document.getElementById('signupName').value.trim();
  const email = document.getElementById('signupEmail').value.trim();
  const pass = document.getElementById('signupPassword').value;
  const confirm = document.getElementById('confirmPassword').value;
  const terms = document.getElementById('termsCheck').checked;
  if (!terms) return showMsg('signupMsg', '❌ Please accept the terms.', 'error');
  if (pass !== confirm) return showMsg('signupMsg', '❌ Passwords do not match.', 'error');
  if (pass.length < 6) return showMsg('signupMsg', '❌ Password too short.', 'error');
  const users = JSON.parse(localStorage.getItem('luxe_users') || '[]');
  if (users.find(u => u.email === email)) return showMsg('signupMsg', '❌ Email already registered.', 'error');
  users.push({ name, email, password: pass });
  localStorage.setItem('luxe_users', JSON.stringify(users));
  localStorage.setItem('luxe_user', JSON.stringify({ name, email }));
  showMsg('signupMsg', '✅ Account created! Redirecting…', 'success');
  setTimeout(() => window.location.href = 'index.html', 1200);
});