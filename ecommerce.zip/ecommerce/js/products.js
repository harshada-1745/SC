const PRODUCTS = [
  { id:1, name:'Wireless Earbuds Pro', cat:'electronics', price:1999, rating:4.5, emoji:'🎧' },
  { id:2, name:'Smart Watch X1', cat:'electronics', price:3499, rating:4.8, emoji:'⌚' },
  { id:3, name:'4K Action Camera', cat:'electronics', price:4299, rating:4.3, emoji:'📷' },
  { id:4, name:'Silk Evening Gown', cat:'fashion', price:2799, rating:4.6, emoji:'👗' },
  { id:5, name:'Leather Crossbody Bag', cat:'fashion', price:1599, rating:4.4, emoji:'👜' },
  { id:6, name:'Classic Sneakers', cat:'fashion', price:2199, rating:4.7, emoji:'👟' },
  { id:7, name:'Luxury Face Serum', cat:'beauty', price:899, rating:4.9, emoji:'🧴' },
  { id:8, name:'Perfume Collection', cat:'beauty', price:1299, rating:4.5, emoji:'🌸' },
  { id:9, name:'Jade Roller Set', cat:'beauty', price:649, rating:4.2, emoji:'💎' },
  { id:10, name:'Bamboo Desk Organiser', cat:'home', price:549, rating:4.3, emoji:'🗂️' },
  { id:11, name:'Aromatherapy Diffuser', cat:'home', price:799, rating:4.6, emoji:'🕯️' },
  { id:12, name:'Ceramic Tea Set', cat:'home', price:1199, rating:4.8, emoji:'🍵' },
];

let filtered = [...PRODUCTS];

function filterProducts() {
  const search = document.getElementById('searchInput').value.toLowerCase();
  const checkedCats = [...document.querySelectorAll('.filter-section input[type=checkbox]:checked')].map(c=>c.value);
  const maxPrice = parseInt(document.getElementById('priceRange').value);
  const sort = document.getElementById('sortSelect').value;
  filtered = PRODUCTS.filter(p => {
    const matchCat = !checkedCats.length || checkedCats.includes(p.cat);
    const matchPrice = p.price <= maxPrice;
    const matchSearch = p.name.toLowerCase().includes(search) || p.cat.includes(search);
    return matchCat && matchPrice && matchSearch;
  });
  if (sort === 'low') filtered.sort((a,b) => a.price - b.price);
  else if (sort === 'high') filtered.sort((a,b) => b.price - a.price);
  else if (sort === 'rating') filtered.sort((a,b) => b.rating - a.rating);
  renderProducts();
}

function updatePrice(el) {
  document.getElementById('priceLabel').textContent = `Up to ₹${el.value}`;
  filterProducts();
}

function renderProducts() {
  const grid = document.getElementById('productsGrid');
  if (!filtered.length) { grid.innerHTML = '<p style="color:#aaa;padding:2rem">No products found.</p>'; return; }
  grid.innerHTML = filtered.map(p => `
    <div class="product-card">
      <div class="product-img">${p.emoji}</div>
      <div class="product-info">
        <div class="product-cat">${p.cat}</div>
        <div class="product-name">${p.name}</div>
        <div class="product-bottom">
          <div class="product-price">₹${p.price.toLocaleString()}</div>
          <div class="product-rating">${'★'.repeat(Math.floor(p.rating))} ${p.rating}</div>
        </div>
        <button class="add-btn" onclick="addToCart(${p.id})">Add to Cart</button>
      </div>
    </div>`).join('');
}

function addToCart(id) {
  const p = PRODUCTS.find(x => x.id === id);
  if (!p) return;
  const cart = getCart();
  const ex = cart.find(x => x.id === id);
  if (ex) ex.qty++; else cart.push({ ...p, qty: 1 });
  saveCart(cart);
  showToast(`🛒 ${p.name} added to cart!`);
}

// Pre-filter by URL param
const urlCat = new URLSearchParams(location.search).get('cat');
if (urlCat) {
  const cb = document.querySelector(`.filter-section input[value="${urlCat}"]`);
  if (cb) { cb.checked = true; }
}

renderProducts();