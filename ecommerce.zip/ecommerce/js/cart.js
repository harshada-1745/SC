function renderCart() {
  const cart = getCart();
  const container = document.getElementById('cartItems');
  if (!cart.length) {
    container.innerHTML = `<div class="empty-cart"><div class="icon">🛒</div><h3>Your cart is empty</h3><p>Add some products to get started!</p><a href="products.html" style="display:inline-block;margin-top:1rem;color:var(--gold)">Browse Products →</a></div>`;
    updateSummary(0); return;
  }
  container.innerHTML = cart.map(item => `
    <div class="cart-card">
      <div class="cart-emoji">${item.emoji}</div>
      <div class="cart-info">
        <h4>${item.name}</h4>
        <span class="price">₹${(item.price * item.qty).toLocaleString()}</span>
        <div class="qty-ctrl">
          <button onclick="changeQty(${item.id}, -1)">−</button>
          <span>${item.qty}</span>
          <button onclick="changeQty(${item.id}, 1)">+</button>
        </div>
      </div>
      <button class="remove-btn" onclick="removeItem(${item.id})" title="Remove">🗑️</button>
    </div>`).join('');
  const total = cart.reduce((s, i) => s + i.price * i.qty, 0);
  updateSummary(total);
}

function updateSummary(total) {
  document.getElementById('subtotal').textContent = `₹${total.toLocaleString()}`;
  document.getElementById('shipping').textContent = total > 999 ? 'FREE' : '₹99';
  const shipping = total > 999 ? 0 : 99;
  let discount = parseInt(localStorage.getItem('luxe_discount') || '0');
  const finalTotal = Math.max(0, total + shipping - discount);
  document.getElementById('totalPrice').textContent = `₹${finalTotal.toLocaleString()}`;
}

function changeQty(id, delta) {
  const cart = getCart();
  const item = cart.find(x => x.id === id);
  if (!item) return;
  item.qty += delta;
  if (item.qty <= 0) cart.splice(cart.indexOf(item), 1);
  saveCart(cart); renderCart();
}

function removeItem(id) {
  const cart = getCart().filter(x => x.id !== id);
  saveCart(cart); renderCart();
  showToast('Item removed from cart');
}

function applyCoupon() {
  const code = document.getElementById('couponInput').value.trim().toUpperCase();
  const coupons = { 'LUXE10': 200, 'SAVE50': 500, 'WELCOME': 150 };
  if (coupons[code]) {
    localStorage.setItem('luxe_discount', coupons[code]);
    showToast(`✅ Coupon applied! -₹${coupons[code]} off`);
    renderCart();
  } else {
    showToast('❌ Invalid coupon code');
  }
}

function checkout() {
  const user = getUser();
  if (!user) { showToast('Please login to checkout!'); setTimeout(() => window.location.href = 'auth.html', 1500); return; }
  const cart = getCart();
  if (!cart.length) { showToast('Your cart is empty!'); return; }
  localStorage.removeItem('luxe_cart');
  localStorage.removeItem('luxe_discount');
  saveCart([]);
  showToast('🎉 Order placed successfully! Thank you!');
  setTimeout(() => window.location.href = 'index.html', 2000);
}

document.addEventListener('DOMContentLoaded', renderCart);