// Global auth & cart utilities
function getUser() { return JSON.parse(localStorage.getItem('luxe_user') || 'null'); }
function getCart() { return JSON.parse(localStorage.getItem('luxe_cart') || '[]'); }
function saveCart(cart) { localStorage.setItem('luxe_cart', JSON.stringify(cart)); updateBadge(); }

function updateBadge() {
  const cart = getCart();
  const total = cart.reduce((s, i) => s + i.qty, 0);
  document.querySelectorAll('#cartBadge').forEach(b => b.textContent = total);
}

function showToast(msg) {
  const t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg; t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2800);
}

// Render nav auth state
function renderNavAuth() {
  const el = document.getElementById('navAuth');
  if (!el) return;
  const user = getUser();
  if (user) {
    el.innerHTML = `<span style="color:#c9a84c;font-size:.85rem">👤 ${user.name || user.email}</span>
    <button onclick="logout()" style="margin-left:.8rem;background:none;border:1px solid #555;color:#aaa;padding:.3rem .8rem;border-radius:15px;cursor:pointer;font-size:.8rem">Logout</button>`;
  } else {
    el.innerHTML = `<a href="auth.html" class="btn-outline">Login</a>`;
  }
}

function logout() {
  localStorage.removeItem('luxe_user');
  window.location.href = 'index.html';
}

document.addEventListener('DOMContentLoaded', () => { renderNavAuth(); updateBadge(); });